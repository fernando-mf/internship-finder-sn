@extends('layouts.app') 

@section('content')
    <div class="jumbotron text-center">
        <div class="container">
            <h1>Liste des milieux de stages</h1>
            <p class="lead">
                Une application faite par les étudiants pour les étudiants
            </p>
        </div>
    </div>
@endsection