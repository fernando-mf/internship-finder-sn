<?php if(count($post->inside_contacts) > 0): ?>
    <div class="panel panel-default">
        <div class="panel-heading">
            Contact, personne resource ou superviseur de stage
        </div>
        <div class="panel-body">
            <?php $__currentLoopData = $post->inside_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <span class="col-md-12">
                        <strong><?php echo e($contact->name); ?></strong>
                    </span>
                </div>
                <?php if($contact->email): ?>
                    <div class="row">
                        <div class="col-md-12 col-md-offset-1 col-xs-offset-1">
                            <span class="glyphicon glyphicon-envelope icon-sp" aria-hidden="true"></span>
                            <a href="mailto:<?php echo e($contact->email); ?>" target="_top"><?php echo e($contact->email); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($contact->phone != null): ?>
                    <div class="row">
                        <div class="col-md-12 col-md-offset-1 col-xs-offset-1">
                            <span class="glyphicon glyphicon-earphone icon-sp" aria-hidden="true"></span>
                            <a href="tel:<?php echo e($contact->phone); ?>" target="_top"><?php echo e($contact->phone); ?></a>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($contact->ext_poste != null): ?>
                    <div class="row">
                        <div class="col-md-12 col-md-offset-1 col-xs-offset-1">
                            <span><strong>Ext/Poste</strong></span>
                            <span class="icon-sp m"><?php echo e($contact->ext_poste); ?></span>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endif; ?>