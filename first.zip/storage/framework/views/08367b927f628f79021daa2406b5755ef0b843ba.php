<?php $__env->startSection('content'); ?>
    
    <div class="well">
        <h1>
            <?php echo e($post->title); ?>

        </h1>
        <br>
        <div class="row">
            <div class="col-md-12">
                <strong>Programme : </strong> <?php echo e($post->program->name); ?>

                <br><br>
                <?php echo e($post->body); ?>

            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <?php echo $__env->make('inc.panels.post.companyInfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-md-6">
                <?php echo $__env->make('inc.panels.post.contactInfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-xs-6 text-left">
                <small class="text-muted">Publié par <?php echo e($post->getUserName()); ?> le <?php echo e($post->getDateString()); ?></small>
            </div>
        </div>
        <hr>
        <?php if(!Auth::guest()): ?>
            <?php if(Auth::user()->id == $post->user_id): ?>
                <a href="<?php echo e(route('posts.edit', ['post' => $post->id])); ?>" class="btn btn-default">Éditer</a>

                <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <?php echo e(Form::submit('Supprimer', ['class' => 'btn btn-danger'])); ?>

                <?php echo Form::close(); ?>

            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>