<?php $__env->startSection('content'); ?>
    
    <div class="well">
        <h1><strong><?php echo e($company->name); ?></strong></h1>

        <div class="row">
            <div class="col-md-12">
                <strong>Site web : </strong> <a href="<?php echo e($company->website); ?>" target="_blank"><?php echo e($company->website); ?></a>
            </div>
        </div>
        <br>

        <?php if($company->phone != null): ?>
            <div class="row">
                <div class="col-md-12">
                    <span class="glyphicon glyphicon-earphone icon-sp" aria-hidden="true"></span>
                    <a href="tel:<?php echo e($company->phone); ?>" target="_top"><?php echo e($company->phone); ?></a>
                </div>
            </div>
            <br>
        <?php endif; ?>
        
         <?php echo $__env->make('inc.panels.company.contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
        
        
    
    <?php if(count($company->posts) > 0): ?>
        <h4 style="text-decoration:underline;"><strong>Publications liées à cette entreprise</strong></h4>
        <div class="row">
            <div class="col-md-12">
                <div class="list-group"> 
                    <?php $__currentLoopData = $company->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item">
                            <div class="row">
                                <div class="col-md-6 col-xs-6 text-left">
                                    <small class="text-muted">Publié par <?php echo e($post->getUserName()); ?> </small>
                                </div>
                                <div class="col-md-6 col-xs-6 text-right">
                                    <span class="badge text-muted"><?php echo e($post->getDateString()); ?></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('posts.show', ['index' => $post->id ])); ?>"><?php echo e($post->title); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                </div>
            </div>
        </div>
    <?php endif; ?>
        <hr>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>