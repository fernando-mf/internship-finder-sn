<?php if(count($company->inside_contacts) > 0): ?>
    <div class="row">
        <span class="col-md-12 col-xs-12">
            <h4 style="text-decoration: underline;">
                <strong>Contacts et personnes resources dans l'entreprise</strong>
            </h4>
        </span>
    </div>

    <div class="row">
        <?php $__currentLoopData = $company->inside_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <strong><?php echo e($contact->name); ?></strong>
                    </div>
                    <div class="panel-body">

                        <?php if($contact->email): ?>
                            <div class="row">
                                <div class="col-md-12 col-md-offset-1 col-xs-offset-1">
                                    <span class="glyphicon glyphicon-envelope icon-sp" aria-hidden="true"></span>
                                    <a href="mailto:<?php echo e($contact->email); ?>" target="_top"><?php echo e($contact->email); ?></a>
                                </div>
                            </div>
                        <?php endif; ?> 
                        
                        <?php if($contact->phone != null): ?>
                            <div class="row">
                                <div class="col-md-12 col-md-offset-1 col-xs-offset-1">
                                    <span class="glyphicon glyphicon-earphone icon-sp" aria-hidden="true"></span>
                                    <a href="tel:<?php echo e($contact->phone); ?>" target="_top"><?php echo e($contact->phone); ?></a>
                                </div>
                            </div>
                        <?php endif; ?> 
                        
                        <?php if($contact->ext_poste != null): ?>
                            <div class="row">
                                <div class="col-md-12 col-md-offset-1 col-xs-offset-1">
                                    <span>
                                        <strong>Ext/Poste</strong>
                                    </span>
                                    <span class="icon-sp m"><?php echo e($contact->ext_poste); ?></span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>