<footer class="footer">
	<div class="container">
		<span class="text-center">
            <strong>Institut Teccart &copy; {{date('Y')}}</strong>
        </span>
	</div>
</footer>