<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('inc.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php if(auth()->guard('admin')->check()): ?>
        <h2 class="text-center main">Modifiez cette publication</h2>
    <?php else: ?>
        <h2 class="text-center main">Modifiez votre publication</h2>
    <?php endif; ?>
    <br>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('posts.update', ['id' => $post->id])); ?>">
                <input name="_method" type="hidden" value="PUT">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <strong>Information sur le stage</strong>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <?php echo e(csrf_field()); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'title', 'c_description' => 'Titre']); ?>
                            <input id="title" type="text" class="form-control" name="title" value="<?php echo e(old('title', $post->title)); ?>" required autofocus > 
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'body', 'c_description' => 'Description']); ?>
                            <textarea rows="5" id="body" class="form-control" name="body" placeholder="Décrivez votre expérience de stage p.ex: Les tâches que vous avez faites, l'environnement de travail, la formation reçue dans la compagnie, etc"><?php echo e(old('body', $post->body)); ?></textarea>
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'program', 'c_description' => 'Programme']); ?>
                            <select name="program" id="program" class="form-control">
                                <?php $__currentLoopData = App\Program::all()->where('code', '!=', '0'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(old('program', $post->program_id) == $program->id): ?>
                                        <option selected="selected" value="<?php echo e($program->id); ?>"><?php echo e($program->name); ?> - <?php echo e($program->code); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($program->id); ?>"><?php echo e($program->name); ?> - <?php echo e($program->code); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <strong>Contact, personne resource ou superviseur de stage</strong>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <?php $__env->startComponent('components.control', ['c_name' => 'co_name', 'c_description' => 'Nom']); ?>
                            <input id="co_name" type="text" class="form-control" name="co_name" value="<?php echo e(old('co_name', $contact->name)); ?>">
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'co_email', 'c_description' => 'Adresse courriel']); ?>
                            <input id="co_email" type="email" class="form-control" name="co_email" value="<?php echo e(old('co_email', $contact->email)); ?>">
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'co_phone', 'c_description' => 'Téléphone']); ?>
                            <input id="co_phone" type="text" class="form-control" name="co_phone" value="<?php echo e(old('co_phone', $contact->phone)); ?>" placeholder="(123) 456-7890" onkeydown="backspacerDOWN(this,event)" onkeyup="backspacerUP(this,event)">
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'co_ext', 'c_description' => 'Poste / Ext']); ?>
                            <input id="co_ext" type="text" class="form-control" name="co_ext" value="<?php echo e(old('co_ext', $contact->ext_poste)); ?>">
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-12 text-center">
                        <button type="submit" class="btn btn-primary">
                            Modifier
                        </button>
                    </div>
                </div>
            </form>
         </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>