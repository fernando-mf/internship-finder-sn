


<nav id="mainNav" class="navbar navbar-default navbar-<?php echo e(Request::is('/')? 'fixed':'static'); ?>-top">
	<div class="container-fluid">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span> Menu
				<i class="fa fa-bars"></i>
			</button>
			
			<a class="navbar-brand" href="<?php echo e(route('index')); ?>">
				Stages Institut Teccart
			</a>
		</div>

		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<ul class="nav navbar-nav">
				<?php if (\Illuminate\Support\Facades\Blade::check('logged')): ?>
					<li>
						<a href="<?php echo e(route('posts.index')); ?>">Publications</a>
					</li>
					<li>
						<a href="<?php echo e(route('companies.index')); ?>">Milieux de stages</a>
					</li>
					<li>
						<a href="<?php echo e(route('stages.index')); ?>">Offres de stage</a>
					</li>
					<?php if(auth()->guard('admin')->check()): ?>
						<li>
							<a href="<?php echo e(route('stages.create')); ?>">Ajouter offre de stage</a>
						</li>

						<?php if (\Illuminate\Support\Facades\Blade::check('master')): ?>
							<li>
								<a href="<?php echo e(route('admin.create')); ?>">Ajouter un administrateur</a>
							</li>
						<?php endif; ?>

					<?php endif; ?>
				<?php endif; ?>
			</ul>

			<ul class="nav navbar-nav navbar-right">
				<!-- Authentication Links -->
				<?php if(auth()->guard('admin')->check()): ?> 
					<li>
						<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
																document.getElementById('logout-form').submit();">
							Se déconnecter
						</a>

						<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
							<?php echo e(csrf_field()); ?>

						</form>
					</li>
				<?php endif; ?> 
				
				<?php if(auth()->guard('web')->check()): ?> 
					<?php echo $__env->make('inc.drop.student', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
				<?php endif; ?> 
			
				<?php if (\Illuminate\Support\Facades\Blade::check('visitor')): ?>
					<li>
						<a href="<?php echo e(route('admin.login')); ?>">Administration</a>
					</li>
					<li>
						<a href="<?php echo e(route('login')); ?>">Se connecter</a>
					</li>
					<li>
						<a href="<?php echo e(route('register')); ?>">Créer un compte</a>
					</li>
				<?php endif; ?>
			</ul>
		</div>
		<!-- /.navbar-collapse -->
	</div>
	<!-- /.container-fluid -->
</nav>