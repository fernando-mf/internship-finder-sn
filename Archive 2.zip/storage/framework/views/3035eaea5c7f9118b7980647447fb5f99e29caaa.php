<?php $__env->startSection('content'); ?>
    <h2 class="text-center main">
        Offres de stage
    </h2>
    <br>
    <?php if(count($jobs) > 0): ?>
        <div class="list-group"> 
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="list-group-item">
                    <div class="row">
                        <div class="col-md-12">
                            <h4>
                                <span class="glyphicon glyphicon-pushpin icon-sp" aria-hidden="true"></span>
                                <a href="<?php echo e(route('stages.show', ['stage' => $job->id ])); ?>"><?php echo e($job->title); ?></a>
                            </h4>
                        </div>
                    </div>
                    <div class="row">
                        <span class="col-md-12">
                            <strong>Catégorie : </strong><?php echo e($job->category->name); ?>

                        </span>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-xs-6 text-left">
                            <span class="text-muted">Publié par <?php echo e($job->company->name); ?> </span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-xs-6 text-left">
                            <span class="text-muted">Le <?php echo e($job->getDateString()); ?> </span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </div>
        <div class="text-center">
            <?php echo e($jobs->links()); ?>

        </div> 
    <?php else: ?>
        <p class="main">Aucune offre de stage trouvée.</p>
    <?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>