<li class="dropdown">
	<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">
		<?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?>

		<span class="caret"></span>
	</a>

	<ul class="dropdown-menu">
		<li>
			<a href="<?php echo e(route('profil')); ?>">
				Mon Profil
			</a>
		</li>

        <li>
			<a href="<?php echo e(route('posts.create')); ?>">
				Ajouter une éxperience de stage
			</a>
		</li>

		<li>
			<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
				Se déconnecter
			</a>

			<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
				<?php echo e(csrf_field()); ?>

			</form>
		</li>
	</ul>
</li>