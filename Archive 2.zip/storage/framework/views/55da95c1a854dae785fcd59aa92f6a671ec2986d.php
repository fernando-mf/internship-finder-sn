<div class="form-group<?php echo e($errors->has($c_name) ? ' has-error' : ''); ?>">
	<label for="<?php echo e($c_name); ?>" class="col-md-12 text-center"><?php echo e($c_description); ?></label>

	<div class="col-md-10 col-md-offset-1">
		
        <?php echo e($slot); ?>

        <?php if($errors->has($c_name)): ?>
		<span class="help-block">
			<strong><?php echo e($errors->first($c_name)); ?></strong>
		</span>
		<?php endif; ?>
	</div>
</div>