 

<?php $__env->startSection('content'); ?>
    
    <header>
        <div class="header-content">
            <div class="header-content-inner">
                <h1 id="homeHeading">Trouvez votre stage dès maintenant</h1>
                <hr>
                <p class="lead"><strong><em>Une application faite par des étudiants pour des étudiants!</em></strong></p>
                <?php if (\Illuminate\Support\Facades\Blade::check('visitor')): ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-xl page-scroll">Commencer</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>