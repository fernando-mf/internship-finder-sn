<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4><?php echo e($user->getName()); ?></h4>
                </div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <span class="col-md-12"><strong>Programme : </strong><?php echo e($user->program->getName()); ?></span>
                    </div>
                    <div class="row">
                        <span class="col-md-12"><strong>Adresse Courriel : </strong><?php echo e($user->email); ?></span>
                    </div>
                    <br>
                    <div class="row">
                        <span class="col-md-12">
                            <a href="<?php echo e(route('user.edit')); ?>">Modifer mes informations</a>
                        </span>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-12">
                            <?php if(count($user->posts) > 0): ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <h4><strong>Vos publications</strong></h4>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <?php $__currentLoopData = $user->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="list-group-item">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <a href="<?php echo e(route('posts.show', ['index' => $post->id ])); ?>"><?php echo e($post->title); ?></a>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <span class="col-md-12"><small>Publié le <?php echo e($post->getDateString()); ?></small></span>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <a href="<?php echo e(route('posts.create')); ?>">Ajouter une publication</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>