<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('favicon.png')); ?>" type="image/png">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    
    <header>
        <div class="header-content">
            <div class="header-content-inner">
                <h1 id="homeHeading"><em>404</em></h1>
                <hr>
                <p class="lead"><strong><em>Cette page n'existe pas.</em></strong></p>
                <a href="<?php echo e(route('index')); ?>" class="btn btn-primary btn-xl page-scroll">OK</a>
            </div>
        </div>
    </header>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>