<?php $__env->startSection('content'); ?>
    <h2 class="main text-center">Ajouter une offre de stage</h2>
    <br>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('stages.store')); ?>">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <strong>Information sur l'entreprise</strong>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <?php $__env->startComponent('components.control', ['c_name' => '_', 'c_description' => '']); ?>
                            <select id="company_search" class="form-control" autofocus>
                                <option value="">Trouver une entreprise</option>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php echo $__env->renderComponent(); ?>

                        <input type="hidden" id="up" value="<?php echo e(old('up')); ?>" name="up">
                        
                        <?php $__env->startComponent('components.control', ['c_name' => 'company', 'c_description' => 'Nom de l\'entreprise']); ?>
                            <input id="company" type="text" class="form-control" name="company" value="<?php echo e(old('company')); ?>" required>
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'website', 'c_description' => 'Site web']); ?>
                            <input id="website" type="url" class="form-control" name="website" value="<?php echo e(old('website')); ?>" placeholder="https://www.entreprise.com" required>
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'phone', 'c_description' => 'Téléphone (Facultatif)']); ?>
                            <input id="phone" type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="(123) 456-7890" onkeydown="backspacerDOWN(this,event)" onkeyup="backspacerUP(this,event)">
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'adresse', 'c_description' => 'Adresse (Facultatif)']); ?>
                            <input id="adresse" type="text" class="form-control" name="adresse" value="<?php echo e(old('adresse')); ?>">
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'ville', 'c_description' => 'Ville (Facultatif)']); ?>
                            <input id="ville" type="text" class="form-control" name="ville" value="<?php echo e(old('ville')); ?>">
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'postal', 'c_description' => 'Code Postal (Facultatif)']); ?>
                            <input id="postal" type="text" class="form-control" name="postal" value="<?php echo e(old('postal')); ?>">
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <strong>Information sur le poste</strong>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <?php echo e(csrf_field()); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'title', 'c_description' => 'Titre']); ?>
                            <input id="title" type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" required> 
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'category', 'c_description' => 'Catégorie']); ?>
                            <select id="category" name="category" class="form-control">
                                <?php $__currentLoopData = App\JobCategory::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(old('category') == $category->id): ?>
                                        <option selected="selected" value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php echo $__env->renderComponent(); ?>
                        <br>
                        <?php $__env->startComponent('components.control_editor', ['c_name' => 'body_editor', 'c_description' => 'Description']); ?>
                            
                            <textarea rows="5" id="body_editor" class="form-control" name="body_editor"><?php echo old('body_editor'); ?></textarea>
                        <?php echo $__env->renderComponent(); ?>

                    </div>
                </div>
                

                <div class="form-group">
                    <div class="col-md-12 text-center">
                        <button type="submit" class="btn btn-primary">
                            Ajouter
                        </button>
                    </div>
                </div>
            </form>
         </div>
    </div>
    <br>
    <script>
        var apiBase = "<?php echo e(route('api.search')); ?>";
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>