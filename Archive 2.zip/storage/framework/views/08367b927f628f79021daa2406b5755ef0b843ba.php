<?php $__env->startSection('content'); ?>
    
    <div class="well">
        <h1>
            <?php echo e($post->title); ?>

        </h1>
        <br>
        <div class="row">
            <div class="col-md-12">
                <strong>Programme : </strong> <?php echo e($post->program->name); ?>

                <br><br>
                <?php echo e($post->body); ?>

            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <?php echo $__env->make('inc.panels.post.companyInfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="col-md-6">
                <?php echo $__env->make('inc.panels.post.contactInfo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-xs-6 text-left">
                <small class="text-muted">Publié par <?php echo e($post->getUserName()); ?> le <?php echo e($post->getDateString()); ?></small>
            </div>
        </div>
        <hr>
        <?php if(!Auth::guest()): ?>
            <?php if(Auth::user()->id == $post->user_id or auth()->guard('admin')->check()): ?>
                <a href="<?php echo e(route('posts.edit', ['post' => $post->id])); ?>" class="btn btn-default">Éditer</a>

                <?php if(auth()->guard('admin')->check()): ?>
                    <div class="pull-right">
                        <a href="#" class="btn btn-danger" data-toggle="modal" data-target="#smallModal">Supprimer</a>
                    </div>

                    <div class="modal fade" id="smallModal" tabindex="-1" role="dialog" aria-labelledby="smallModal" aria-hidden="true">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    <h4 class="modal-title" id="myModalLabel"><strong>Êtes-vous sûr de vouloir supprimer cette publication?</strong></h4>
                                </div>
                                <div class="modal-body text-center">
                                    <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST']); ?>

                                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                    <button type="button" class="btn btn-default" data-dismiss="modal">Non</button>
                                    <?php echo e(Form::submit('Oui', ['class' => 'btn btn-danger'])); ?>

                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>