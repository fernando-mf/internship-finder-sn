 
<?php $__env->startSection('content'); ?> 
    <?php echo $__env->make('inc.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <h2 class="text-center main">Ajouter une expérience de stage</h2>
    <br>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('posts.store')); ?>">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <strong>Information sur le stage</strong>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <?php echo e(csrf_field()); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'title', 'c_description' => 'Titre']); ?>
                            <input id="title" type="text" class="form-control" name="title" value="<?php echo e(old('title')); ?>" required autofocus > 
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'body', 'c_description' => 'Description']); ?>
                            <textarea rows="5" id="body" class="form-control" name="body" placeholder="Décrivez votre expérience de stage p.ex: Les tâches que vous avez faites, l'environnement de travail, la formation reçue dans la compagnie, etc"><?php echo e(old('body')); ?></textarea>
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'program', 'c_description' => 'Programme']); ?>
                            <select name="program" id="program" class="form-control">
                                <?php $__currentLoopData = App\Program::all()->where('code', '!=', '0'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(old('program') == $program->id || Auth::user()->program_id == $program->id): ?>
                                        <option selected="selected" value="<?php echo e($program->id); ?>"><?php echo e($program->name); ?> - <?php echo e($program->code); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($program->id); ?>"><?php echo e($program->name); ?> - <?php echo e($program->code); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <strong>Information sur l'entreprise</strong>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <?php $__env->startComponent('components.control', ['c_name' => '_', 'c_description' => '']); ?>
                            <select id="company_search" class="form-control">
                                <option value="">Trouver une entreprise</option>
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php echo $__env->renderComponent(); ?>

                        <input type="hidden" id="up" value="" name="up">
                        
                        <?php $__env->startComponent('components.control', ['c_name' => 'company', 'c_description' => 'Nom de l\'entreprise']); ?>
                            <input id="company" type="text" class="form-control" name="company" value="<?php echo e(old('company')); ?>" required>
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'website', 'c_description' => 'Site web']); ?>
                            <input id="website" type="url" class="form-control" name="website" value="<?php echo e(old('website')); ?>" placeholder="https://www.entreprise.com" required>
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'phone', 'c_description' => 'Téléphone (Facultatif)']); ?>
                            <input id="phone" type="text" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="(123) 456-7890" onkeydown="backspacerDOWN(this,event)" onkeyup="backspacerUP(this,event)">
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <strong>Contact, personne resource ou superviseur de stage (Facultatif)</strong>
                        </h3>
                    </div>
                    <div class="panel-body">
                        <?php $__env->startComponent('components.control', ['c_name' => 'co_name', 'c_description' => 'Nom']); ?>
                            <input id="co_name" type="text" class="form-control" name="co_name" value="<?php echo e(old('co_name')); ?>">
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'co_email', 'c_description' => 'Adresse courriel']); ?>
                            <input id="co_email" type="email" class="form-control" name="co_email" value="<?php echo e(old('co_email')); ?>">
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'co_phone', 'c_description' => 'Téléphone']); ?>
                            <input id="co_phone" type="text" class="form-control" name="co_phone" value="<?php echo e(old('co_phone')); ?>" placeholder="(123) 456-7890" onkeydown="backspacerDOWN(this,event)" onkeyup="backspacerUP(this,event)">
                        <?php echo $__env->renderComponent(); ?>

                        <?php $__env->startComponent('components.control', ['c_name' => 'co_ext', 'c_description' => 'Poste / Ext']); ?>
                            <input id="co_ext" type="text" class="form-control" name="co_ext" value="<?php echo e(old('co_ext')); ?>">
                        <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-12 text-center">
                        <button type="submit" class="btn btn-primary">
                            Ajouter
                        </button>
                    </div>
                </div>
            </form>
         </div>
    </div>
    <script>
        var apiBase = "<?php echo e(route('api.search')); ?>";
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>