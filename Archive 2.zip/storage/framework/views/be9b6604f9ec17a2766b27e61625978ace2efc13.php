<footer class="footer">
	<div class="container">
		<span class="text-center">
            <strong>Institut Teccart &copy; <?php echo e(date('Y')); ?></strong>
        </span>
	</div>
</footer>