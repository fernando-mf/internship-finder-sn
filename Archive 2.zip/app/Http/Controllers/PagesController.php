<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;

class PagesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth:web,admin');
    }

    public function index(){
        // Temp
        //return view('login');
        return view('pages.index');
    }

    public function logout(){
        return redirect()->route('index');
    }
}